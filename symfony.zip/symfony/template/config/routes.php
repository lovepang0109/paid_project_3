<?php
use Symfony\Component\Routing\RouteCollection;
use Symfony\Component\Routing\Route;


$routes = new RouteCollection();

$routes->add('index', new Route('/', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\RedirectController::redirectAction',
    'route'       => 'default-dashboard',
]));

// Dashboard
$routes->add('default-dashboard', new Route('default-dashboard', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'dashboard/dashboard.html.twig',
]));

$routes->add('ecommerce_dashboard', new Route('ecommerce_dashboard', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'dashboard/ecommerce.html.twig',
]));

$routes->add('online_course', new Route('online_course', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'dashboard/online_course.html.twig',
]));

$routes->add('crypto', new Route('crypto', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'dashboard/crypto.html.twig',
]));

$routes->add('social', new Route('social', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'dashboard/social.html.twig',
]));

// Widgets
$routes->add('chart-widget', new Route('chart-widget', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'widgets/chart-widget.html.twig',
]));
$routes->add('general-widget', new Route('general-widget', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'widgets/general-widget.html.twig',
]));

// Project
$routes->add('projects', new Route('projects', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'project/projects.html.twig',
]));

$routes->add('projectcreate', new Route('projectcreate', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'project/projectcreate.html.twig',
]));



// Ecommerce
$routes->add('product', new Route('product', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/product.html.twig',
]));

$routes->add('page-product', new Route('page-product', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/product-page.html.twig',
]));

$routes->add('list-products', new Route('list-products', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/list-products.html.twig',
]));

$routes->add('payment-details', new Route('payment-details', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/payment-details.html.twig',
]));

$routes->add('order-history', new Route('order-history', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/order-history.html.twig',
]));

$routes->add('invoice-template', new Route('invoice-template', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/invoice-template.html.twig',
]));

$routes->add('cart', new Route('cart', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/cart.html.twig',
]));

$routes->add('list-wish', new Route('list-wish', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/list-wish.html.twig',
]));

$routes->add('checkout', new Route('checkout', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/checkout.html.twig',
]));

$routes->add('pricing', new Route('pricing', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ecommerce/pricing.html.twig',
]));

// Email
$routes->add('email-application', new Route('email-application', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'email/email-application.html.twig',
]));

$routes->add('email-compose', new Route('email-compose', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'email/email-compose.html.twig',
]));

// Chat
$routes->add('chat', new Route('chat', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'chat/chat.html.twig',
]));

$routes->add('video-chat', new Route('video-chat', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'chat/chat-video.html.twig',
]));

// Users
$routes->add('user-profile', new Route('user-profile', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'users/user-profile.html.twig',
]));

$routes->add('edit-profile', new Route('edit-profile', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'users/edit-profile.html.twig',
]));

$routes->add('user-cards', new Route('user-cards', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'users/user-cards.html.twig',
]));


// Forms
$routes->add('form-validation', new Route('form-validation', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_controls/form-validation.html.twig',
]));

$routes->add('base-input', new Route('base-input', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_controls/base-input.html.twig',
]));

$routes->add('radio-checkbox-control', new Route('radio-checkbox-control', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_controls/radio-checkbox-control.html.twig',
]));

$routes->add('megaoptions', new Route('megaoptions', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_controls/megaoptions.html.twig',
]));

$routes->add('input-group', new Route('input-group', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_controls/input-group.html.twig',
]));

// Forms->form_widgets
$routes->add('datepicker', new Route('datepicker', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_widgets/datepicker.html.twig',
]));

$routes->add('time-picker', new Route('time-picker', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_widgets/time-picker.html.twig',
]));

$routes->add('datetimepicker', new Route('datetimepicker', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_widgets/datetimepicker.html.twig',
]));

$routes->add('daterangepicker', new Route('daterangepicker', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_widgets/daterangepicker.html.twig',
]));

$routes->add('touchspin', new Route('touchspin', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_widgets/touchspin.html.twig',
]));

$routes->add('select2', new Route('select2', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_widgets/select2.html.twig',
]));

$routes->add('typeahead', new Route('typeahead', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_widgets/typeahead.html.twig',
]));

$routes->add('clipboard', new Route('clipboard', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_widgets/clipboard.html.twig',
]));
$routes->add('switch', new Route('switch', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_widgets/switch.html.twig',
]));


// Forms->form_layouts

$routes->add('default-form', new Route('default-form', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_layouts/default-form.html.twig',
]));

$routes->add('form-wizard', new Route('form-wizard', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_layouts/form-wizard.html.twig',
]));

$routes->add('form-wizard-two', new Route('form-wizard-two', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_layouts/form-wizard-two.html.twig',
]));

$routes->add('form-wizard-three', new Route('form-wizard-three', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'forms/form_layouts/form-wizard-three.html.twig',
]));

// Tables

// Tables->Bootstrap Tables
$routes->add('bootstrap-basic-table', new Route('bootstrap-basic-table', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'tables/bootstrap_tables/bootstrap-basic-table.html.twig',
]));
$routes->add('table-components', new Route('table-components', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'tables/bootstrap_tables/table-components.html.twig',
]));

// Tables->Data Tables
$routes->add('datatable-basic-init', new Route('datatable-basic-init', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'tables/data_tables/datatable-basic-init.html.twig',
]));
$routes->add('datatable-api', new Route('datatable-api', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'tables/data_tables/datatable-API.html.twig',
]));
$routes->add('datatable-data-source', new Route('datatable-data-source', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'tables/data_tables/datatable-data-source.html.twig',
]));


// Tables->ex_data_tables
$routes->add('datatable-ext-autofill', new Route('datatable-ext-autofill', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'tables/ex_data_tables/datatable-ext-autofill.html.twig',
]));

// Jsgrid Table
$routes->add('jsgrid-table', new Route('jsgrid-table', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'tables/jsgrid-table.html.twig',
]));

// Ui Kits
$routes->add('typography', new Route('typography', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/typography.html.twig',
]));

$routes->add('avatars', new Route('avatars', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/avatars.html.twig',
]));

$routes->add('helper-classes', new Route('helper-classes', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/helper-classes.html.twig',
]));

$routes->add('grid', new Route('grid', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/grid.html.twig',
]));

$routes->add('tag-pills', new Route('tag-pills', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/tag-pills.html.twig',
]));

$routes->add('progress-bar', new Route('progress-bar', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/progress-bar.html.twig',
]));

$routes->add('modal', new Route('modal', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/modal.html.twig',
]));

$routes->add('alert', new Route('alert', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/alert.html.twig',
]));

$routes->add('popover', new Route('popover', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/popover.html.twig',
]));

$routes->add('tooltip', new Route('tooltip', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/tooltip.html.twig',
]));

$routes->add('tooltip', new Route('tooltip', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/tooltip.html.twig',
]));

$routes->add('loader', new Route('loader', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/loader.html.twig',
]));

$routes->add('dropdown', new Route('dropdown', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/dropdown.html.twig',
]));

$routes->add('according', new Route('according', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/according.html.twig',
]));

$routes->add('box-shadow', new Route('box-shadow', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/box-shadow.html.twig',
]));

$routes->add('list', new Route('list', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/list.html.twig',
]));

$routes->add('tab-bootstrap', new Route('tab-bootstrap', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/tabs/tab-bootstrap.html.twig',
]));

$routes->add('tab-material', new Route('tab-material', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'ui_kits/tabs/tab-material.html.twig',
]));

// Bonus ui kits 
$routes->add('scrollable', new Route('scrollable', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/scrollable.html.twig',
]));

$routes->add('tree', new Route('tree', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/tree.html.twig',
]));

$routes->add('bootstrap-notify', new Route('bootstrap-notify', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/bootstrap-notify.html.twig',
]));

$routes->add('rating', new Route('rating', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/rating.html.twig',
]));

$routes->add('dropzone', new Route('dropzone', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/dropzone.html.twig',
]));

$routes->add('tour', new Route('tour', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/tour.html.twig',
]));

$routes->add('sweet-alert2', new Route('sweet-alert2', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/sweet-alert2.html.twig',
]));

$routes->add('animated-modal', new Route('animated-modal', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/modal-animated.html.twig',
]));

$routes->add('owl-carousel', new Route('owl-carousel', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/owl-carousel.html.twig',
]));

$routes->add('ribbons', new Route('ribbons', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/ribbons.html.twig',
]));

$routes->add('pagination', new Route('pagination', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/pagination.html.twig',
]));

$routes->add('ribbons', new Route('ribbons', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/ribbons.html.twig',
]));

$routes->add('breadcrumb', new Route('breadcrumb', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/breadcrumb.html.twig',
]));

$routes->add('range-slider', new Route('range-slider', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/range-slider.html.twig',
]));

$routes->add('image-cropper', new Route('image-cropper', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/image-cropper.html.twig',
]));

$routes->add('sticky', new Route('sticky', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/sticky.html.twig',
]));

$routes->add('basic-card', new Route('basic-card', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/basic-card.html.twig',
]));

$routes->add('creative-card', new Route('creative-card', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/creative-card.html.twig',
]));

$routes->add('tabbed-card', new Route('tabbed-card', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/tabbed-card.html.twig',
]));

$routes->add('dragable-card', new Route('dragable-card', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/dragable-card.html.twig',
]));

$routes->add('timeline-v-1', new Route('timeline-v-1', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/timeline/timeline-v-1.html.twig',
]));

$routes->add('timeline-v-2', new Route('timeline-v-2', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bonus_ui/timeline/timeline-v-2.html.twig',
]));

$routes->add('form-builder-1', new Route('form-builder-1', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'builders/form-builder-1.html.twig',
]));

$routes->add('form-builder-2', new Route('form-builder-2', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'builders/form-builder-2.html.twig',
]));

$routes->add('pagebuild', new Route('pagebuild', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'builders/pagebuild.html.twig',
]));

$routes->add('button-builder', new Route('button-builder', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'builders/button-builder.html.twig',
]));

// Animations
$routes->add('animate', new Route('animate', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'animation/animate.html.twig',
]));

$routes->add('aos', new Route('aos', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'animation/aos.html.twig',
]));

$routes->add('scroll-reval', new Route('scroll-reval', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'animation/scroll-reval.html.twig',
]));

$routes->add('tilt', new Route('tilt', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'animation/tilt.html.twig',
]));

$routes->add('wow', new Route('wow', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'animation/wow.html.twig',
]));

$routes->add('feather-icon', new Route('feather-icon', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'icons/feather-icon.html.twig',
]));

$routes->add('flag-icon', new Route('flag-icon', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'icons/flag-icon.html.twig',
]));

$routes->add('feather-icon', new Route('feather-icon', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'icons/feather-icon.html.twig',
]));

$routes->add('font-awesome', new Route('font-awesome', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'icons/font-awesome.html.twig',
]));

$routes->add('ico-icon', new Route('ico-icon', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'icons/ico-icon.html.twig',
]));

$routes->add('font-awesome', new Route('font-awesome', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'icons/font-awesome.html.twig',
]));

$routes->add('themify-icon', new Route('themify-icon', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'icons/themify-icon.html.twig',
]));

$routes->add('whether-icon', new Route('whether-icon', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'icons/whether-icon.html.twig',
]));

// Buttons
$routes->add('button-group', new Route('button-group', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'buttons/button-group.html.twig',
]));

$routes->add('button-group', new Route('button-group', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'buttons/button-group.html.twig',
]));

$routes->add('buttons-edge', new Route('buttons-edge', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'buttons/buttons-edge.html.twig',
]));

$routes->add('buttons-flat', new Route('buttons-flat', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'buttons/buttons-flat.html.twig',
]));

$routes->add('buttons', new Route('buttons', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'buttons/buttons.html.twig',
]));

$routes->add('raised-button', new Route('raised-button', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'buttons/raised-button.html.twig',
]));

// Gallery
$routes->add('gallery-hover', new Route('gallery-hover', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'gallery/gallery-hover.html.twig',
]));

$routes->add('gallery', new Route('gallery', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'gallery/gallery.html.twig',
]));

$routes->add('description-with-gallery', new Route('description-with-gallery', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'gallery/gallery-with-description.html.twig',
]));

$routes->add('gallery-masonry', new Route('gallery-masonry', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'gallery/gallery-masonry.html.twig',
]));

$routes->add('gallery-masonry', new Route('gallery-masonry', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'gallery/gallery-masonry.html.twig',
]));

$routes->add('masonry-gallery-with-disc', new Route('masonry-gallery-with-disc', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'gallery/masonry-gallery-with-disc.html.twig',
]));

// Blog

$routes->add('add-post', new Route('add-post', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'blog/add-post.html.twig',
]));

$routes->add('blog-single', new Route('blog-single', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'blog/blog-single.html.twig',
]));

$routes->add('blog-single', new Route('blog-single', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'blog/blog-single.html.twig',
]));

$routes->add('blog', new Route('blog', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'blog/blog.html.twig',
]));

//Job Search

$routes->add('job-cards-view', new Route('job-cards-view', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'job_search/job-cards-view.html.twig',
]));

$routes->add('job-list-view', new Route('job-list-view', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'job_search/job-list-view.html.twig',
]));

$routes->add('job-details', new Route('job-details', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'job_search/job-details.html.twig',
]));

$routes->add('job-apply', new Route('job-apply', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'job_search/job-apply.html.twig',
]));

// Maps
$routes->add('map-js', new Route('map-js', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'maps/map-js.html.twig',
]));

$routes->add('vector-map', new Route('vector-map', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'maps/vector-map.html.twig',
]));

// Editors
$routes->add('summernote', new Route('summernote', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'editors/summernote.html.twig',
]));

$routes->add('ckeditor', new Route('ckeditor', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'editors/ckeditor.html.twig',
]));

$routes->add('simple-mde', new Route('simple-mde', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'editors/simple-MDE.html.twig',
]));

$routes->add('ace-code-editor', new Route('ace-code-editor', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'editors/ace-code-editor.html.twig',
]));


// Learning
$routes->add('learning-detailed', new Route('learning-detailed', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'learning/learning-detailed.html.twig',
]));

$routes->add('learning-list-view', new Route('learning-list-view', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'learning/learning-list-view.html.twig',
]));

// Error pages

$routes->add('error-400', new Route('error-400', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/error_pages/error-400.html.twig',
]));

$routes->add('error-401', new Route('error-401', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/error_pages/error-401.html.twig',
]));

$routes->add('error-403', new Route('error-403', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/error_pages/error-403.html.twig',
]));

$routes->add('error-404', new Route('error-404', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/error_pages/error-404.html.twig',
]));

$routes->add('error-500', new Route('error-500', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/error_pages/error-500.html.twig',
]));

$routes->add('error-503', new Route('error-503', [
        '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
        'template'    => 'others/error_pages/error-503.html.twig',
]));

// Email templates
$routes->add('basic-template', new Route('basic-template', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/email_templates/basic-template.html.twig',
]));

$routes->add('email-header', new Route('email-header', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/email_templates/email-header.html.twig',
]));

$routes->add('template-email', new Route('template-email', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/email_templates/template-email.html.twig',
]));

$routes->add('template-email-2', new Route('template-email-2', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/email_templates/template-email-2.html.twig',
]));

$routes->add('ecommerce-templates', new Route('ecommerce-templates', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/email_templates/ecommerce-templates.html.twig',
]));

$routes->add('email-order-success', new Route('email-order-success', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/email_templates/email-order-success.html.twig',
]));


// Comming soon
$routes->add('comingsoon', new Route('comingsoon', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/coming_soon/comingsoon.html.twig',
]));

$routes->add('comingsoon-bg-video', new Route('comingsoon-bg-video', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/coming_soon/comingsoon-bg-video.html.twig',
]));

$routes->add('comingsoon-bg-img', new Route('comingsoon-bg-img', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/coming_soon/comingsoon-bg-img.html.twig',
]));

// Authenticatations

$routes->add('login', new Route('login', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/login.html.twig',
]));

$routes->add('login_one', new Route('login_one', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/login_one.html.twig',
]));

$routes->add('login_two', new Route('login_two', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/login_two.html.twig',
]));

$routes->add('login-bs-validation', new Route('login-bs-validation', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/login-bs-validation.html.twig',
]));

$routes->add('login-bs-tt-validation', new Route('login-bs-tt-validation', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/login-bs-tt-validation.html.twig',
]));

$routes->add('login-sa-validation', new Route('login-sa-validation', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/login-sa-validation.html.twig',
]));

$routes->add('sign-up', new Route('sign-up', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/sign-up.html.twig',
]));

$routes->add('sign-up-one', new Route('sign-up-one', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/sign-up-one.html.twig',
]));

$routes->add('sign-up-two', new Route('sign-up-two', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/sign-up-two.html.twig',
]));

$routes->add('sign-up-wizard', new Route('sign-up-wizard', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/sign-up-wizard.html.twig',
]));

$routes->add('unlock', new Route('unlock', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/unlock.html.twig',
]));

$routes->add('forget-password', new Route('forget-password', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/forget-password.html.twig',
]));

$routes->add('reset-password', new Route('reset-password', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/reset-password.html.twig',
]));

$routes->add('maintenance', new Route('maintenance', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'others/authentication/maintenance.html.twig',
]));

// Page-layout
$routes->add('box-layout', new Route('box-layout', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'page_layout/box-layout.html.twig',
]));

$routes->add('layout-rtl', new Route('layout-rtl', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'page_layout/layout-rtl.html.twig',
]));

$routes->add('layout-dark', new Route('layout-dark', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'page_layout/layout-dark.html.twig',
]));

$routes->add('hide-on-scroll', new Route('hide-on-scroll', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'page_layout/hide-on-scroll.html.twig',
]));

$routes->add('footer-light', new Route('footer-light', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'page_layout/footer-light.html.twig',
]));

$routes->add('footer-fixed', new Route('footer-fixed', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'page_layout/footer-fixed.html.twig',
]));

$routes->add('footer-fixed', new Route('footer-fixed', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'page_layout/footer-fixed.html.twig',
]));

$routes->add('footer-dark', new Route('footer-dark', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'page_layout/footer-dark.html.twig',
]));

// File manager
$routes->add('file-manager', new Route('file-manager', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'file-manager.html.twig',
]));

// Bookmark
$routes->add('bookmark', new Route('bookmark', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'bookmark.html.twig',
]));

// faq
$routes->add('faq', new Route('faq', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'faq.html.twig',
]));

// contact
$routes->add('contacts', new Route('contacts', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'contacts.html.twig',
]));

// sample-page
$routes->add('sample-page', new Route('sample-page', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'sample-page.html.twig',
]));

// Task
$routes->add('task', new Route('task', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'task.html.twig',
]));

// calendar
$routes->add('calendar-basic', new Route('calendar-basic', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'calendar-basic.html.twig',
]));

// knowledgebase
$routes->add('knowledgebase', new Route('knowledgebase', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'knowledgebase.html.twig',
]));

// support-ticket.html
$routes->add('support-ticket', new Route('support-ticket', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'support-ticket.html.twig',
]));

// kanban
$routes->add('kanban', new Route('kanban', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'kanban.html.twig',
]));

// internationalization
$routes->add('internationalization', new Route('internationalization', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'internationalization.html.twig',
]));

$routes->add('social-app', new Route('social-app', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'social-app.html.twig',
]));

$routes->add('to-do', new Route('to-do', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'to-do.html.twig',
]));

$routes->add('search', new Route('search', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'search.html.twig',
]));

// charts
$routes->add('echarts', new Route('echarts', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/echarts.html.twig',
]));

$routes->add('chart-apex', new Route('chart-apex', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chart-apex.html.twig',
]));

$routes->add('chart-google', new Route('chart-google', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chart-google.html.twig',
]));

$routes->add('chart-sparkline', new Route('chart-sparkline', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chart-sparkline.html.twig',
]));

$routes->add('chart-flot', new Route('chart-flot', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chart-flot.html.twig',
]));

$routes->add('chart-knob', new Route('chart-knob', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chart-knob.html.twig',
]));

$routes->add('chart-knob', new Route('chart-knob', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chart-knob.html.twig',
]));

$routes->add('chart-morris', new Route('chart-morris', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chart-morris.html.twig',
]));

$routes->add('chartjs', new Route('chartjs', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chartjs.html.twig',
]));

$routes->add('chartist', new Route('chartist', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chartist.html.twig',
]));

$routes->add('chart-peity', new Route('chart-peity', [
    '_controller' => 'Symfony\Bundle\FrameworkBundle\Controller\TemplateController',
    'template'    => 'charts/chart-peity.html.twig',
]));




return $routes;