<?php

namespace App;

use Symfony\Component\HttpKernel\Kernel as BaseKernel;
use Symfony\Bundle\FrameworkBundle\Kernel\MicroKernelTrait;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

class Kernel extends BaseKernel
{
    use MicroKernelTrait;

    protected function configureRoutes(RoutingConfigurator $routes){

        $extensions = '{php,xml,yaml}';

        $routes->import('../config/{routes}' . $this->environment . "/*.$extensions");  
        $routes->import("../config/{routes}/*.$extensions");
        $routes->import("../config/{routes}.$extensions");

    }
}
