import React, { Fragment } from 'react';
import { Breadcrumbs } from '../../AbstractElements';

const Form1 = () => {
    return (
        <Fragment>
            <Breadcrumbs mainTitle='Form Builder 1' parent='Form Builder' title='Form Builder 1' />
        </Fragment>
    );
};

export default Form1;